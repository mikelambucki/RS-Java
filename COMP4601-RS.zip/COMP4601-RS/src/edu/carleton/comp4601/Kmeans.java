package edu.carleton.comp4601;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Kmeans {

    private int no_users;
    private User[] users;
    private int no_features;
    private boolean changed;
    private int no_clusters;

    /*
     * Constructor that reads the data in from a file.
     * You must specify the number of clusters.
     */
    public Kmeans(int noClusters, File file) throws FileNotFoundException {
        changed = true;
        Scanner s = new Scanner(file);

        no_users = s.nextInt();
        no_features = s.nextInt();
        users = new User[no_users];
        this.no_clusters = noClusters;

        for (int i = 0; i < no_users; i++) {
            String name = s.next();
            users[i] = new User(name, no_features, noClusters);
            for (int j = 0; j < no_features; j++) {
                users[i].features[j] = s.nextDouble();
            }
        }
        s.close();
    }

    /*
     * This is where your implementation goes
     */


    private int MAX_ITERATIONS = 1000;
    public void algorithm() {
        for (int i = 0; i < no_users; i++)
            System.out.println(users[i].toString());

        List<List<Double>> centroids = new ArrayList<>();
        for (int i = 0; i < no_clusters; i++) {
            List<Double> s = new ArrayList<>();
            for (int x = 0; x < no_features; x++) {
                s.add(Math.random() * 3);
            }

            centroids.add(s);
        }


        int iterations = 0;

        while (changed) {
                      // Your code here
            if (iterations++ > MAX_ITERATIONS) {
                System.out.println("Max iterations reached");
                break;
            }


            changed = false;
            for (int i = 0; i < no_users; i++) {
                double min = 1000000;
                for (int x = 0; x < no_clusters; x++) {
                    double s = distance(centroids.get(x), users[i]);
                    if (s < min) {
                        min = s;
                        users[i].update(x);
                        changed = changed || users[i].changed();
                    }
                }
            }



            for (int i = 0; i < no_clusters; i++) {
                List<Double> max = new ArrayList<>();
                List<Double> min = new ArrayList<>();

                for (int a = 0; a < no_features; a++) {
                    max.add(0.0);
                    min.add(100000.0);
                }

                for (int x = 0; x < no_users; x++) {
                    if (users[x].cluster == i) {
                        for (int a = 0; a < no_features; a++) {
                            max.set(a, Math.max(max.get(a), users[x].features[a]));
                            min.set(a, Math.min(min.get(a), users[x].features[a]));
                        }
                    }
                }


                for (int a = 0; a < no_features; a++) {
                    centroids.get(i).set(a, (max.get(a) + min.get(a)) / 2);
                }

            }

        }


        System.out.println("Showing centroids:");
        for (List<Double> centroid: centroids) {
            System.out.println(centroid);
        }


        double min = 0;
        for (int i = 0; i < no_users; i++) {
            min += distance(centroids.get(users[i].cluster), users[i]);
        }


        System.out.println(min);
    }


    //distance between centroid and user
    public double distance(List<Double> centroid, User b) {
        double rtn = 0.0;
        // Assumes a and b have same number of features
        for (int i = 0; i < b.features.length; i++) {
            rtn += (centroid.get(i) - b.features[i])
                    * (centroid.get(i) - b.features[i]);
        }
        return Math.sqrt(rtn);
    }

    // Private class for representing user
    private class User {
        public double[] features;
        public double[] distance;
        public String name;
        public int cluster;
        public int last_cluster;

        public User(String name, int noFeatures, int noClusters) {
            this.name = name;
            this.features = new double[noFeatures];
            this.distance = new double[noClusters];
            this.cluster = -1;
            this.last_cluster = -2;
        }

        // Check if cluster association has changed.
        public boolean changed() {
            return last_cluster != cluster;
        }

        // Update the saved cluster from iteration to iteration
        public void update(int c) {
            last_cluster = cluster;
            cluster = c;
        }

        public double distance(User b) {
            double rtn = 0.0;
            // Assumes a and b have same number of features
            for (int i = 0; i < this.features.length; i++) {
                rtn += (this.features[i] - b.features[i])
                        * (this.features[i] - b.features[i]);
            }
            return Math.sqrt(rtn);
        }

        public String toString() {
            StringBuffer b = new StringBuffer(name);
            for (int i = 0; i < features.length; i++) {
                b.append(' ');
                b.append(features[i]);
            }
            return b.toString();
        }
    }

}