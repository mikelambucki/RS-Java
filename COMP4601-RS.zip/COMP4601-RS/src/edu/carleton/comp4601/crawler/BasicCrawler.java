
package edu.carleton.comp4601.crawler;

import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.TikaInputStream;	
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.BodyContentHandler;
import org.jgrapht.graph.Multigraph;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URL;
import java.net.UnknownHostException;

import edu.carleton.comp4601.dao.Database;
import edu.carleton.comp4601.utility.WebGraph;
import edu.uci.ics.crawler4j.crawler.Page;
import edu.uci.ics.crawler4j.crawler.WebCrawler;
import edu.uci.ics.crawler4j.parser.HtmlParseData;
import edu.uci.ics.crawler4j.url.WebURL;

/*
 * MICHAEL LAMBUCKI 101013418
 * COLE TRAYNOR 101013430
 * 
 * 
 * 
 */
public class BasicCrawler extends WebCrawler {

	private static final Pattern IMAGE_EXTENSIONS = Pattern.compile(".*(\\.(css|js|bmp|vcf|ico" + "|mid|mp2|mp3|mp4"
			+ "|wav|avi|mov|mpeg|ram|m4v" + "|rm|smil|wmv|swf|wma|zip|rar|gz))$");
	
	
	private static final Pattern BINARY_EXTENSIONS = Pattern.compile((".*(\\.(jpeg|tiff|gif|png|pdf|doc|docx|xls|xlsx|ppt|pptx))$"));
	
	public Database db;
	public org.bson.Document dbDoc;
	public Date dateStart;
	public Date dateEnd;

	/**
	 * You should implement this function to specify whether the given url
	 * should be crawled or not (based on your crawling logic).
	 */
	@Override
	public boolean shouldVisit(Page referringPage, WebURL url) {
		// Ignore the url if it has an extension that matches our defined set of
		// image extensions.
		
		String href = url.getURL().toLowerCase();
        boolean check = (!IMAGE_EXTENSIONS.matcher(href).matches()
				&& href.startsWith("https://sikaman.dyndns.org/courses/4601/assignments/training/pages/") || href
							.startsWith("https://sikaman.dyndns.org/courses/4601/resources/"));
        return check;
		// Only accept the url if it is in the domain and protocol is "http".
	}
	
	
	public BasicCrawler() {
		super();
		
		try {
			db = new Database();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This function is called when a page is fetched and ready to be processed
	 * by your program.
	 */
	@Override
	public void visit(Page page) {
		
		dateStart = new Date();
		
		dbDoc = new org.bson.Document();
		int docid = page.getWebURL().getDocid();
		int parentDocid = page.getWebURL().getParentDocid();
		String url = page.getWebURL().getURL();
		String parentUrl = page.getWebURL().getParentUrl();

		
		dbDoc.append("_id", docid);
		dbDoc.append("url", url);
		Multigraph<Integer, org.jgrapht.graph.DefaultEdge> mg = WebGraph.getInstance().getMultigraph();
		mg.addVertex(Integer.valueOf(docid));
		if (parentUrl != null) {
			mg.addEdge(Integer.valueOf(docid), Integer.valueOf(parentDocid));
		} else {
			mg.addEdge(Integer.valueOf(docid), Integer.valueOf(0));
		}

		if (page.getParseData() instanceof HtmlParseData) {
			HtmlParseData htmlParseData = (HtmlParseData) page.getParseData();
			String text = htmlParseData.getText();
			String html = htmlParseData.getHtml();
			Set<WebURL> urls = htmlParseData.getOutgoingUrls();
			ArrayList<String> tags = new ArrayList<String>();
			
			
			System.out.println("HTML");
			Document doc = Jsoup.parse(html);
			String imgSelector = "img[src~=(?i)\\.(png|jpe?g|gif)]";
			Elements imgs = doc.select(imgSelector);
			for (Element e : imgs) {
				//String src = e.attr("src");
				String alt = e.attr("alt");
				//images.add(src);
				if (alt != null && !alt.isEmpty())
					tags.add(alt);
			}
			
			String title = doc.title();
			dbDoc.append("name",title.toString());
			ArrayList<String> links = new ArrayList<>();
			for (Element e : doc.select("a[href]")) {
				// System.out.println("link:"+e.toString());
				String link = e.attr("abs:href");

				if (link != null && !link.isEmpty()) {
					links.add(link);
				}
			}
			
			dbDoc.append("tags",tags);
			dbDoc.append("links", links);
			
			//System.out.println("inserting to db.... HTML");
			db.insertDocument(dbDoc);
			
			
			


		} else if(BINARY_EXTENSIONS.matcher(url).matches()){
			Tika tika	=	new Tika();
			try{
			Metadata  metadata = new	Metadata();
			java.io.InputStream	input = TikaInputStream.get(new URL(url), metadata);
			org.xml.sax.ContentHandler	handler = new BodyContentHandler(2000000);
			ParseContext	context	=	new ParseContext();	
			Parser	parser	=	new AutoDetectParser();	
			parser.parse(input,	handler,	metadata,	context);	
			
			dbDoc.append("name", metadata.get("title"));
			dbDoc.append("text", handler.toString());
			dbDoc.append("formattype", metadata.get(Metadata.CONTENT_TYPE));
			
			
			System.out.println("inserting to db.... NOT HTML");
			db.database.getCollection("Tika").insertOne(dbDoc);
			input.close();
			
			} catch (IOException | org.xml.sax.SAXException | TikaException err ){
				err.printStackTrace();
			}
		}
		
		
		}
	}

