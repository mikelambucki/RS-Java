package edu.carleton.comp4601.resources;
/*
 * MICHAEL LAMBUCKI 101013418
 * COLE TRAYNOR 101013430
 * 
 * 
 * 
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import javax.xml.bind.JAXBElement;

import org.jsoup.Jsoup;

import edu.carleton.comp4601.dao.Document;
import edu.carleton.comp4601.dao.Documents;

@Path("/rs")
public class Recommender {
		// Allows to insert contextual objects into the class,
		// e.g. ServletContext, Request, Response, UriInfo
		@Context
		UriInfo uriInfo;
		@Context
		Request request;
		@Context
		ServletContext context;
		
		private String name;
		
		//DocumentCollection dc = new DocumentCollection();

		public Recommender() {
			name = "COMP4601 Recommender: Michael Lambucki and Cole Traynor";
		}
		
		@GET
		public String printName() {
			return name;
		}
		
		
		//Delete documents with specified tags
		@GET
		@Path("/reset/{dir}")
		public String initialize(@PathParam("dir") String dir) {
			return "Here, " + dir + " represents the directory being used as the root directory for access to web pages and users. This will be used during testing to access testing data (the data referenced here is training data). For example, while training the value of dir will be 'training' reflecting the use of the data in the comp4601/assignments/training directory; however, a tester might choose dir = 'testing' to access data in the comp4601/assignments/testing/pages and comp4601/assignments/testing/users directories.";
		}
		
		@GET
		@Path("/context")
		public String analyzePages() {
			return "analyzes the web pages and returns an HTML representation of the profiles for users. The HTML returned must clearly show what features are being used as part of the profile for a user. It is expected that the response would contain an HTML table with one row containing information for a user.";
		}
		
		@GET
		@Path("/community")
		public String communityReturn() {
			return "if run after the /context web service, returns an HTML representation of the communities computed for the users. The HTML must contain a table in which each row contains the community name (C-X, X = 1,..., m) followed by a cell containing a comma delimited list of user names. Should the community service be run before the context service an error should be generated.";
		}
		
		@GET
		@Path("/fetch/user/{page}")
		public String getUserPage(@PathParam("page") String page){
			return "retrieves a page from the context specified in (8) (a testing set will be specified after the submission deadline) and augments it with advertising. Your web service must consist of 2 frames, one containing the content of the requested page, and the other containing advertising.";
		}
		
		@GET
		@Path("advertising/{category}")
		public String getCategory(@PathParam("category") String page){
			return "Shows advertising category selected.";
		}
		
		private String getResource(String path) {
			InputStream is = context.getResourceAsStream(path);
			StringBuilder builder = new StringBuilder();
			try (Reader reader = new BufferedReader(new InputStreamReader(is, Charset.forName(StandardCharsets.UTF_8.name())))) {
				int c = 0;
				while ((c = reader.read()) != -1) {
					builder.append((char) c);
				}
				
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			return builder.toString();
		}		
		
		
		
		
		
}

